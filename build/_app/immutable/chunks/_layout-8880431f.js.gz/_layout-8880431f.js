const r=!0,t=!1,e="true",s=Object.freeze(Object.defineProperty({__proto__:null,prerender:!0,ssr:!1,trailingSlash:e},Symbol.toStringTag,{value:"Module"}));export{s as _,r as p,t as s,e as t};
