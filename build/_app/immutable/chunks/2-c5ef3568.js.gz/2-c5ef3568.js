import{default as t}from"../components/pages/_page.svelte-1c375175.js";export{t as component};
