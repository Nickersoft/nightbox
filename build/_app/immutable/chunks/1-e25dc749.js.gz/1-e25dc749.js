import{default as t}from"../components/error.svelte-8edcca66.js";export{t as component};
