import{p as a,s as e,t as p}from"../../chunks/_layout-8880431f.js";export{a as prerender,e as ssr,p as trailingSlash};
